const express = require('express');
const fs = require('fs');
const path = require('path');
const QRCode = require('qrcode');

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'ChangeThisPassword123!';
const SITE_NAME = process.env.SITE_NAME || 'Certificate Verification Portal';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'certificates.json');

app.use(express.urlencoded({ extended: false }));
app.use(express.json());

function ensureData() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, JSON.stringify([
      { id: 'DEMO-1001', name: 'Sample Student', course: 'Introduction to Web Development', institution: 'Example Learning Institute', issueDate: '11 November 2026', status: 'Valid' }
    ], null, 2));
  }
}
function readRecords() {
  ensureData();
  try { return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch { return []; }
}
function writeRecords(records) {
  ensureData();
  fs.writeFileSync(DATA_FILE, JSON.stringify(records, null, 2));
}
function esc(v='') {
  return String(v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function auth(req, res, next) {
  const header = req.headers.authorization || '';
  if (header.startsWith('Basic ')) {
    const decoded = Buffer.from(header.slice(6), 'base64').toString();
    const split = decoded.indexOf(':');
    const user = decoded.slice(0, split);
    const pass = decoded.slice(split + 1);
    if (user === ADMIN_USER && pass === ADMIN_PASSWORD) return next();
  }
  res.set('WWW-Authenticate', 'Basic realm="Certificate Admin"');
  return res.status(401).send('Admin login required.');
}
function page(title, body) {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><link rel="stylesheet" href="/style.css"></head><body><header><b>✓ ${esc(SITE_NAME)}</b><span>DOCUMENT VERIFICATION</span></header><main>${body}</main><footer>© ${new Date().getFullYear()} ${esc(SITE_NAME)}</footer></body></html>`;
}
function certHtml(record) {
  return page('Certificate Verification', `<section class="certificate"><div class="ribbon">CERTIFICATE RECORD</div><div class="valid">✓ ${esc((record.status || 'Valid').toUpperCase())}</div><p class="eyebrow">CERTIFICATE VERIFICATION</p><h1>${esc(record.name)}</h1><p class="muted">The following certificate record was found in the verification portal.</p><div class="details"><div><label>VERIFICATION ID</label><strong>${esc(record.id)}</strong></div><div><label>COURSE / PROGRAM</label><strong>${esc(record.course)}</strong></div><div><label>ISSUING ORGANIZATION</label><strong>${esc(record.institution)}</strong></div><div><label>DATE OF ISSUE</label><strong>${esc(record.issueDate)}</strong></div></div><p class="disclaimer">This page displays information entered by the portal administrator. It is not independent proof of authenticity from an issuing institution.</p></section>`);
}
app.get('/style.css', (req,res) => res.type('text/css').send(fs.readFileSync(path.join(__dirname,'style.css'),'utf8')));
app.get('/', (req,res) => res.send(page('Certificate Portal', `<section class="hero"><p class="eyebrow">DOCUMENT AUTHENTICATION</p><h1>Certificate Verification Portal</h1><p class="muted">Scan the QR code printed on a certificate to view its individual verification page.</p><p><a class="button" href="/admin">Admin panel</a></p></section>`)));
app.get('/admin', auth, async (req,res) => {
  const records = readRecords();
  const rows = await Promise.all(records.map(async r => {
    const url = `${req.protocol}://${req.get('host')}/cert/${encodeURIComponent(r.id)}`;
    const qr = await QRCode.toDataURL(url, { width: 150, margin: 1 });
    return `<tr><td><b>${esc(r.id)}</b><br><span class="muted">${esc(r.name)}</span></td><td>${esc(r.course)}</td><td><a href="/cert/${encodeURIComponent(r.id)}" target="_blank">Open certificate</a><br><a href="${esc(url)}" target="_blank">${esc(url)}</a></td><td><img class="qr" src="${qr}" alt="QR code for ${esc(r.id)}"><br><a download="QR-${esc(r.id)}.png" href="${qr}">Download QR</a></td><td><form method="post" action="/admin/delete"><input type="hidden" name="id" value="${esc(r.id)}"><button class="danger" type="submit">Delete</button></form></td></tr>`;
  }));
  res.send(page('Admin Panel', `<section class="admin-head"><p class="eyebrow">ADMINISTRATION</p><h1>Manage certificates</h1><p class="muted">Add a record to generate its unique certificate URL and QR code.</p></section><section class="panel"><h2>Add certificate</h2><form method="post" action="/admin/add" class="form"><label>Verification ID<input name="id" placeholder="CERT-2026-003" required></label><label>Certificate holder name<input name="name" required></label><label>Course / Program<input name="course" required></label><label>Issuing organization<input name="institution" required></label><label>Issue date<input name="issueDate" placeholder="11 November 2026" required></label><label>Status<select name="status"><option>Valid</option><option>Revoked</option></select></label><button type="submit">Add certificate & generate QR</button></form></section><section class="panel"><h2>Saved certificates (${records.length})</h2><div class="table-wrap"><table><thead><tr><th>Record</th><th>Course</th><th>Certificate URL</th><th>QR Code</th><th>Action</th></tr></thead><tbody>${rows.join('') || '<tr><td colspan="5">No records yet.</td></tr>'}</tbody></table></div></section><p class="note">Protect this admin login. Set ADMIN_USER and a strong ADMIN_PASSWORD in Render Environment Variables before publishing.</p>`)));
});
app.post('/admin/add', auth, (req,res) => {
  const id = String(req.body.id || '').trim().replace(/[^a-zA-Z0-9_-]/g, '');
  const name = String(req.body.name || '').trim();
  const course = String(req.body.course || '').trim();
  const institution = String(req.body.institution || '').trim();
  const issueDate = String(req.body.issueDate || '').trim();
  const status = req.body.status === 'Revoked' ? 'Revoked' : 'Valid';
  if (!id || !name || !course || !institution || !issueDate) return res.status(400).send('All fields are required.');
  const records = readRecords();
  if (records.some(r => r.id.toLowerCase() === id.toLowerCase())) return res.status(409).send('That verification ID already exists. Use a unique ID.');
  records.push({ id, name, course, institution, issueDate, status });
  writeRecords(records);
  res.redirect('/admin');
});
app.post('/admin/delete', auth, (req,res) => {
  const id = String(req.body.id || '');
  writeRecords(readRecords().filter(r => r.id !== id));
  res.redirect('/admin');
});
app.get('/cert/:id', (req,res) => {
  const record = readRecords().find(r => r.id.toLowerCase() === String(req.params.id).toLowerCase());
  if (!record) return res.status(404).send(page('Not found', '<section class="certificate"><h1>Certificate not found</h1><p class="muted">No matching certificate record exists.</p></section>'));
  res.send(certHtml(record));
});
app.listen(PORT, () => console.log(`Certificate portal listening on ${PORT}`));
